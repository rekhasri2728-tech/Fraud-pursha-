HOW TO USE THIS BIRTHDAY WEBSITE

1. Keep index.html and the photos folder together.
2. Put the MP3 you want to use in this folder and rename it exactly:
   song.mp3
3. Upload index.html + the photos folder + song.mp3 to your GitHub repository.
4. GitHub Pages should publish the site.
5. Make a QR code using the final GitHub Pages URL.

Suggested song:
"Pookkal Pookkum" is a soft romantic Tamil choice for this kind of memory page.
You need to supply the MP3 yourself; the website code does not include copyrighted music.

The music is designed to start after he taps YES, because mobile browsers commonly block automatic audio playback.
